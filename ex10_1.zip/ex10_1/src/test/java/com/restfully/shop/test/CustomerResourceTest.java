package com.restfully.shop.test;

import com.restfully.shop.domain.Customers;
import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.WebTarget;
import java.net.URI;


/**
 * @author <a href="mailto:bill@burkecentral.com">Bill Burke</a>
 * @version $Revision: 1 $
 */
public class CustomerResourceTest
{
   private static Client client;

   @BeforeClass
   public static void initClient()
   {
      client = ClientBuilder.newClient();
   }

   @AfterClass
   public static void closeClient()
   {
      client.close();
   }

   @Test
   public void testQueryCustomers() throws Exception
   {
      URI uri = new URI("http://localhost:8080/services/customers");
      while (uri != null)
      {
         WebTarget target = client.target(uri);
         String output = target.request("application/json").get(String.class);
         System.out.println("** XML from " + uri.toString());
         System.out.println(output);

         Customers customers = target.request("application/json").get(Customers.class);
         if(customers.getNext() != null)
            uri = new URI(customers.getNext());
         else
            uri =  null;
         System.out.println("URI--->"+uri);
      }
   }
}
